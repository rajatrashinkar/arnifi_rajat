# JobConnect Pro

JobConnect Pro is a full-stack job portal web application built as an internship assignment project.

It supports two user roles:
- Recruiter: create and manage job posts, review applications, update candidate status.
- Candidate: discover jobs, apply with cover letter, and upload Resume/CV files.

## Assignment Objective

Build a role-based job platform with authentication, protected routes, CRUD operations, and application workflow.

## Key Features

### Authentication and Authorization
- Signup and login with JWT authentication
- Session restore on refresh
- Role-based route protection
- Candidate and recruiter route guards

### Recruiter Module
- Create, edit, and delete jobs
- View all applications for recruiter-owned jobs
- Change application status: pending, reviewing, accepted, rejected
- View uploaded candidate Resume/CV

### Candidate Module
- Discover and filter active jobs
- Apply with cover letter
- Upload Resume/CV file (PDF, DOC, DOCX, TXT up to 5MB)
- Track application status

### User Experience
- Custom route error boundary for better 404/error pages
- Loading and error states across async flows
- Modern UI built with Tailwind and shadcn/ui components

## Tech Stack

### Frontend
- React 19
- TypeScript
- Redux Toolkit
- React Router 7
- Axios
- Tailwind CSS + shadcn/ui
- Vite

### Backend
- Node.js + Express
- TypeScript
- JWT + bcryptjs
- Multer (Resume/CV upload)
- CORS

## Project Structure

```text
app/
├── server/                 # Express backend
│   ├── middleware/         # auth middleware
│   ├── models/             # in-memory data model
│   ├── routes/             # auth/jobs/applications APIs
│   ├── index.ts            # dev API server
│   └── production.ts       # production server (serves frontend + API)
├── src/                    # React frontend
│   ├── api/                # API client layer
│   ├── pages/              # feature pages
│   ├── store/              # redux slices
│   ├── components/         # reusable UI components
│   └── types/              # TS interfaces
├── uploads/                # uploaded resume files (created at runtime)
└── README.md
```

## Setup and Run

### Prerequisites
- Node.js 20+
- npm

### Installation

```bash
npm install
```

### Run full application (recommended)

```bash
npm run dev:full
```

This starts:
- Frontend: http://localhost:5173
- Backend API: http://localhost:3001

### Run separately

```bash
# Terminal 1
npm run server:dev

# Terminal 2
npm run dev
```

## Demo Credentials

Recruiter
- Email: recruiter@techcorp.com
- Password: password123

Candidate
- Email: candidate@email.com
- Password: password123

## API Summary

Authentication
- POST /api/auth/signup
- POST /api/auth/login
- GET /api/auth/me

Jobs
- GET /api/jobs
- GET /api/jobs/:id
- POST /api/jobs
- PUT /api/jobs/:id
- DELETE /api/jobs/:id

Applications
- GET /api/applications
- POST /api/applications/jobs/:id/apply
- PUT /api/applications/:id/status
- GET /api/applications/job/:jobId

## Resume Upload Notes

- Upload field name: resumeFile
- Allowed types: pdf, doc, docx, txt
- Max size: 5MB
- Files served from: /uploads/<filename>

## Build for Submission

```bash
npm run build
```

## Scripts

- npm run dev: run frontend only
- npm run server:dev: run backend in watch mode
- npm run dev:full: run frontend + backend together
- npm run build: type-check and build frontend
- npm start: run production server

## Known Limitations

- Uses local SQLite database for persistence (stored at server/data/jobconnect.sqlite)
- No cloud/object storage for uploaded files
- No automated test suite yet

## Submission Checklist

- Project runs with npm run dev:full
- Role-based flows work for recruiter and candidate
- Resume/CV upload works in candidate application flow
- Recruiter can open uploaded resume from application details
- Production build succeeds with npm run build

## Additional Documentation

- Backend details: server/README.md
- Frontend details: src/README.md

## License

This project is submitted for internship assignment evaluation.
