# Backend README

## Overview

This backend is an Express + TypeScript API for JobConnect Pro.

Main responsibilities:
- Authentication with JWT
- Job CRUD operations
- Candidate job applications
- Recruiter application management
- Resume/CV file upload and static serving

## Folder Map

```text
server/
├── index.ts                # Development API server
├── production.ts           # Production server (API + static frontend)
├── middleware/
│   └── auth.ts             # JWT auth and role guards
├── models/
│   └── database.ts         # SQLite data layer + seed records
└── routes/
    ├── auth.ts             # signup/login/me
    ├── jobs.ts             # job endpoints
    └── applications.ts     # apply/status/application listing
```

## Run Backend

From project root:

```bash
npm run server:dev
```

Default port: 3001

Health endpoint:

```text
GET /api/health
```

## Authentication Flow

- Login/signup returns JWT token.
- Frontend sends token in Authorization header:
  Bearer <token>
- Protected routes use authMiddleware.
- Role-specific routes use requireRole([...]).

## Resume/CV Upload

Upload endpoint:

```text
POST /api/applications/jobs/:id/apply
```

Form-data fields:
- coverLetter (text, required)
- resumeFile (file, required for normal flow)

Allowed mime types:
- application/pdf
- application/msword
- application/vnd.openxmlformats-officedocument.wordprocessingml.document
- text/plain

Max file size:
- 5MB

Stored location:
- uploads/ directory at project root

Served URL pattern:
- /uploads/<filename>

## API Response Pattern

Most routes return:

```json
{
  "success": true,
  "message": "...",
  "data": {}
}
```

Errors return:

```json
{
  "success": false,
  "message": "..."
}
```

## Notes for Evaluator

- Data layer uses a local SQLite database file for persistence.
- Seed accounts are created only when the database is empty.
- Default DB file path: server/data/jobconnect.sqlite (configurable via DB_PATH).
