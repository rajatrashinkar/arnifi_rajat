import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { db, type Application } from '../models/database';
import { authMiddleware, requireRole, AuthRequest } from '../middleware/auth';

const router = Router();

type RecruiterApplicationView = Application & {
  job: {
    id: string;
    title: string;
    company: string;
  } | null;
  candidate: {
    id: string;
    fullName: string;
    email: string;
    title?: string;
  } | null;
};

const getSingleParam = (value: string | string[] | undefined): string => {
  if (Array.isArray(value)) {
    return value[0] ?? '';
  }
  return value ?? '';
};

const uploadsDir = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (_req, file, cb) => {
    const safeBaseName = path
      .basename(file.originalname, path.extname(file.originalname))
      .replace(/[^a-zA-Z0-9_-]/g, '_');
    cb(null, `${Date.now()}_${safeBaseName}${path.extname(file.originalname).toLowerCase()}`);
  },
});

const allowedMimeTypes = new Set([
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/plain',
]);

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!allowedMimeTypes.has(file.mimetype)) {
      return cb(new Error('Only PDF, DOC, DOCX, and TXT files are allowed.'));
    }
    cb(null, true);
  },
});

// GET /api/applications - Get applications
// Recruiters: get applications for their jobs
// Candidates: get their own applications
router.get('/', authMiddleware, (req: AuthRequest, res) => {
  try {
    const user = req.user!;

    if (user.role === 'candidate') {
      // Get candidate's applications with job details
      const applications = db.findApplicationsByCandidate(user.id);
      const applicationsWithJobs = applications.map(app => {
        const job = db.findJobById(app.jobId);
        return {
          ...app,
          job: job ? {
            id: job.id,
            title: job.title,
            company: job.company,
            location: job.location,
            type: job.type,
          } : null,
        };
      });

      return res.status(200).json({
        success: true,
        data: { applications: applicationsWithJobs },
      });
    } else {
      // Recruiter: get applications for all their jobs
      const recruiterJobs = db.findJobsByRecruiter(user.id);
      const jobIds = recruiterJobs.map(job => job.id);
      
      let allApplications: RecruiterApplicationView[] = [];
      jobIds.forEach(jobId => {
        const apps = db.findApplicationsByJob(jobId);
        const job = db.findJobById(jobId);
        const appsWithDetails = apps.map(app => {
          const candidate = db.findUserById(app.candidateId);
          return {
            ...app,
            job: job ? {
              id: job.id,
              title: job.title,
              company: job.company,
            } : null,
            candidate: candidate ? {
              id: candidate.id,
              fullName: candidate.fullName,
              email: candidate.email,
              title: candidate.title,
            } : null,
          };
        });
        allApplications = [...allApplications, ...appsWithDetails];
      });

      // Sort by application date
      allApplications.sort((a, b) => 
        new Date(b.appliedAt).getTime() - new Date(a.appliedAt).getTime()
      );

      return res.status(200).json({
        success: true,
        data: { applications: allApplications },
      });
    }
  } catch (error) {
    console.error('Get applications error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while fetching applications.',
    });
  }
});

// POST /api/jobs/:id/apply - Apply for a job (candidate only)
router.post('/jobs/:id/apply', authMiddleware, requireRole(['candidate']), upload.single('resumeFile'), (req: AuthRequest, res) => {
  try {
    const jobId = getSingleParam(req.params.id);
    if (!jobId) {
      return res.status(400).json({
        success: false,
        message: 'Invalid job id.',
      });
    }

    const { coverLetter, resume } = req.body;
    const resumeFilePath = req.file ? `/uploads/${req.file.filename}` : '';
    const normalizedCoverLetter = typeof coverLetter === 'string' ? coverLetter.trim() : '';
    const normalizedResumeText = typeof resume === 'string' ? resume.trim() : '';
    const normalizedResume = resumeFilePath || normalizedResumeText;

    // Find job
    const job = db.findJobById(jobId);
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found.',
      });
    }

    // Check if job is active
    if (job.status !== 'active') {
      return res.status(400).json({
        success: false,
        message: 'This job is no longer accepting applications.',
      });
    }

    // Check if already applied
    const hasApplied = db.hasCandidateApplied(jobId, req.user!.id);
    if (hasApplied) {
      return res.status(409).json({
        success: false,
        message: 'You have already applied for this job.',
      });
    }

    // Validation
    if (!normalizedCoverLetter || !normalizedResume) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a cover letter and upload a resume/CV file.',
      });
    }

    // Create application
    const application = db.createApplication({
      jobId,
      candidateId: req.user!.id,
      coverLetter: normalizedCoverLetter,
      resume: normalizedResume,
      resumeFileName: req.file?.originalname,
      resumeMimeType: req.file?.mimetype,
      status: 'pending',
    });

    return res.status(201).json({
      success: true,
      message: 'Application submitted successfully!',
      data: { 
        application: {
          ...application,
          job: {
            id: job.id,
            title: job.title,
            company: job.company,
            location: job.location,
          },
        },
      },
    });
  } catch (error) {
    if (error instanceof multer.MulterError) {
      return res.status(400).json({
        success: false,
        message: error.code === 'LIMIT_FILE_SIZE'
          ? 'Resume/CV file size must be 5MB or less.'
          : 'File upload error. Please try again.',
      });
    }

    if (error instanceof Error && error.message.includes('Only PDF, DOC, DOCX, and TXT files are allowed.')) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    console.error('Apply error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while submitting your application.',
    });
  }
});

// PUT /api/applications/:id/status - Update application status (recruiter only)
router.put('/:id/status', authMiddleware, requireRole(['recruiter']), (req: AuthRequest, res) => {
  try {
    const id = getSingleParam(req.params.id);
    if (!id) {
      return res.status(400).json({
        success: false,
        message: 'Invalid application id.',
      });
    }

    const statusValue = req.body?.status;

    // Validate status
    const validStatuses: Application['status'][] = ['pending', 'reviewing', 'accepted', 'rejected'];
    if (typeof statusValue !== 'string' || !validStatuses.includes(statusValue as Application['status'])) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Must be one of: ${validStatuses.join(', ')}`,
      });
    }
    const status = statusValue as Application['status'];

    // Find application
    const application = db.findApplicationById(id);
    if (!application) {
      return res.status(404).json({
        success: false,
        message: 'Application not found.',
      });
    }

    // Verify recruiter owns the job
    const job = db.findJobById(application.jobId);
    if (!job || job.recruiterId !== req.user!.id) {
      return res.status(403).json({
        success: false,
        message: 'You can only update applications for your own jobs.',
      });
    }

    // Update application status
    const updatedApplication = db.updateApplicationStatus(id, status);
    if (!updatedApplication) {
      return res.status(500).json({
        success: false,
        message: 'Failed to update application status.',
      });
    }

    return res.status(200).json({
      success: true,
      message: `Application ${status} successfully!`,
      data: { application: updatedApplication },
    });
  } catch (error) {
    console.error('Update application status error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while updating the application.',
    });
  }
});

// GET /api/applications/job/:jobId - Get applications for a specific job (recruiter only)
router.get('/job/:jobId', authMiddleware, requireRole(['recruiter']), (req: AuthRequest, res) => {
  try {
    const jobId = getSingleParam(req.params.jobId);
    if (!jobId) {
      return res.status(400).json({
        success: false,
        message: 'Invalid job id.',
      });
    }

    // Verify job exists and belongs to recruiter
    const job = db.findJobById(jobId);
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found.',
      });
    }

    if (job.recruiterId !== req.user!.id) {
      return res.status(403).json({
        success: false,
        message: 'You can only view applications for your own jobs.',
      });
    }

    // Get applications with candidate details
    const applications = db.findApplicationsByJob(jobId);
    const applicationsWithDetails = applications.map(app => {
      const candidate = db.findUserById(app.candidateId);
      return {
        ...app,
        candidate: candidate ? {
          id: candidate.id,
          fullName: candidate.fullName,
          email: candidate.email,
          title: candidate.title,
        } : null,
      };
    });

    return res.status(200).json({
      success: true,
      data: { 
        applications: applicationsWithDetails,
        job: {
          id: job.id,
          title: job.title,
        },
      },
    });
  } catch (error) {
    console.error('Get job applications error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while fetching applications.',
    });
  }
});

export default router;
