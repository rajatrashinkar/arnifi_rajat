import { Router } from 'express';
import { db, Job } from '../models/database';
import { authMiddleware, requireRole, AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/jobs - Get all jobs (public for active jobs, auth for all)
router.get('/', (req: AuthRequest, res) => {
  try {
    // If user is authenticated as recruiter, return their jobs
    if (req.user?.role === 'recruiter') {
      const jobs = db.findJobsByRecruiter(req.user.id);
      return res.status(200).json({
        success: true,
        data: { jobs },
      });
    }

    // For candidates and public access, return only active jobs
    const jobs = db.findAllActiveJobs();
    return res.status(200).json({
      success: true,
      data: { jobs },
    });
  } catch (error) {
    console.error('Get jobs error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while fetching jobs.',
    });
  }
});

// GET /api/jobs/:id - Get single job
router.get('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const job = db.findJobById(id);

    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found.',
      });
    }

    // Only return active jobs to public/candidates
    // Recruiters can see their own jobs regardless of status
    if (job.status !== 'active') {
      if (!req.user || (req.user.role !== 'recruiter' || job.recruiterId !== req.user.id)) {
        return res.status(404).json({
          success: false,
          message: 'Job not found.',
        });
      }
    }

    return res.status(200).json({
      success: true,
      data: { job },
    });
  } catch (error) {
    console.error('Get job error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while fetching the job.',
    });
  }
});

// POST /api/jobs - Create new job (recruiter only)
router.post('/', authMiddleware, requireRole(['recruiter']), (req: AuthRequest, res) => {
  try {
    const { title, description, requirements, location, salary, type, company } = req.body;

    // Validation
    if (!title || !description || !location || !type) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields: title, description, location, type',
      });
    }

    // Validate job type
    const validTypes = ['full-time', 'part-time', 'contract', 'internship'];
    if (!validTypes.includes(type)) {
      return res.status(400).json({
        success: false,
        message: `Invalid job type. Must be one of: ${validTypes.join(', ')}`,
      });
    }

    const job = db.createJob({
      title,
      description,
      requirements: requirements || [],
      location,
      salary: salary || { min: 0, max: 0, currency: 'USD' },
      type,
      recruiterId: req.user!.id,
      company: company || req.user!.email.split('@')[1],
      status: 'active',
    });

    return res.status(201).json({
      success: true,
      message: 'Job posted successfully!',
      data: { job },
    });
  } catch (error) {
    console.error('Create job error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while creating the job.',
    });
  }
});

// PUT /api/jobs/:id - Update job (recruiter only, own jobs)
router.put('/:id', authMiddleware, requireRole(['recruiter']), (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { title, description, requirements, location, salary, type, status, company } = req.body;

    // Find job
    const existingJob = db.findJobById(id);
    if (!existingJob) {
      return res.status(404).json({
        success: false,
        message: 'Job not found.',
      });
    }

    // Verify ownership
    if (existingJob.recruiterId !== req.user!.id) {
      return res.status(403).json({
        success: false,
        message: 'You can only update your own job postings.',
      });
    }

    // Validate status if provided
    if (status && !['active', 'closed', 'draft'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be: active, closed, or draft',
      });
    }

    // Validate job type if provided
    if (type) {
      const validTypes = ['full-time', 'part-time', 'contract', 'internship'];
      if (!validTypes.includes(type)) {
        return res.status(400).json({
          success: false,
          message: `Invalid job type. Must be one of: ${validTypes.join(', ')}`,
        });
      }
    }

    const updates: Partial<Job> = {};
    if (title !== undefined) updates.title = title;
    if (description !== undefined) updates.description = description;
    if (requirements !== undefined) updates.requirements = requirements;
    if (location !== undefined) updates.location = location;
    if (salary !== undefined) updates.salary = salary;
    if (type !== undefined) updates.type = type;
    if (status !== undefined) updates.status = status;
    if (company !== undefined) updates.company = company;

    const updatedJob = db.updateJob(id, updates);

    return res.status(200).json({
      success: true,
      message: 'Job updated successfully!',
      data: { job: updatedJob },
    });
  } catch (error) {
    console.error('Update job error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while updating the job.',
    });
  }
});

// DELETE /api/jobs/:id - Delete job (recruiter only, own jobs)
router.delete('/:id', authMiddleware, requireRole(['recruiter']), (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    // Find job
    const existingJob = db.findJobById(id);
    if (!existingJob) {
      return res.status(404).json({
        success: false,
        message: 'Job not found.',
      });
    }

    // Verify ownership
    if (existingJob.recruiterId !== req.user!.id) {
      return res.status(403).json({
        success: false,
        message: 'You can only delete your own job postings.',
      });
    }

    // Delete job
    const deleted = db.deleteJob(id);

    if (deleted) {
      return res.status(200).json({
        success: true,
        message: 'Job deleted successfully!',
      });
    } else {
      return res.status(500).json({
        success: false,
        message: 'Failed to delete job.',
      });
    }
  } catch (error) {
    console.error('Delete job error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred while deleting the job.',
    });
  }
});

export default router;
