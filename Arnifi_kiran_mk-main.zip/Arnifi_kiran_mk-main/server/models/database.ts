/**
 * SQLite Database for JobConnect Pro
 * Persists users, jobs, and applications to a local database file.
 */

import fs from 'fs';
import path from 'path';
import BetterSqlite3 from 'better-sqlite3';

export type UserRole = 'recruiter' | 'candidate';

export interface User {
  id: string;
  email: string;
  password: string;
  fullName: string;
  role: UserRole;
  company?: string;
  title?: string;
  createdAt: string;
}

export interface Job {
  id: string;
  title: string;
  description: string;
  requirements: string[];
  location: string;
  salary: {
    min: number;
    max: number;
    currency: string;
  };
  type: 'full-time' | 'part-time' | 'contract' | 'internship';
  recruiterId: string;
  company: string;
  status: 'active' | 'closed' | 'draft';
  createdAt: string;
  updatedAt: string;
}

export interface Application {
  id: string;
  jobId: string;
  candidateId: string;
  coverLetter: string;
  resume: string;
  resumeFileName?: string;
  resumeMimeType?: string;
  status: 'pending' | 'reviewing' | 'accepted' | 'rejected';
  appliedAt: string;
  updatedAt: string;
}

type UserRow = {
  id: string;
  email: string;
  password: string;
  fullName: string;
  role: UserRole;
  company: string | null;
  title: string | null;
  createdAt: string;
};

type JobRow = {
  id: string;
  title: string;
  description: string;
  requirements: string;
  location: string;
  salary: string;
  type: Job['type'];
  recruiterId: string;
  company: string;
  status: Job['status'];
  createdAt: string;
  updatedAt: string;
};

type ApplicationRow = {
  id: string;
  jobId: string;
  candidateId: string;
  coverLetter: string;
  resume: string;
  resumeFileName: string | null;
  resumeMimeType: string | null;
  status: Application['status'];
  appliedAt: string;
  updatedAt: string;
};

class Database {
  private sqlite: BetterSqlite3.Database;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'server', 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const dbPath = process.env.DB_PATH || path.join(dataDir, 'jobconnect.sqlite');
    this.sqlite = new BetterSqlite3(dbPath);

    this.sqlite.pragma('foreign_keys = ON');
    this.createTables();
    this.seedData();
  }

  private createTables() {
    this.sqlite.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        fullName TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('recruiter', 'candidate')),
        company TEXT,
        title TEXT,
        createdAt TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        requirements TEXT NOT NULL,
        location TEXT NOT NULL,
        salary TEXT NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('full-time', 'part-time', 'contract', 'internship')),
        recruiterId TEXT NOT NULL,
        company TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('active', 'closed', 'draft')),
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL,
        FOREIGN KEY (recruiterId) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS applications (
        id TEXT PRIMARY KEY,
        jobId TEXT NOT NULL,
        candidateId TEXT NOT NULL,
        coverLetter TEXT NOT NULL,
        resume TEXT NOT NULL,
        resumeFileName TEXT,
        resumeMimeType TEXT,
        status TEXT NOT NULL CHECK(status IN ('pending', 'reviewing', 'accepted', 'rejected')),
        appliedAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL,
        FOREIGN KEY (jobId) REFERENCES jobs(id) ON DELETE CASCADE,
        FOREIGN KEY (candidateId) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
      CREATE INDEX IF NOT EXISTS idx_jobs_recruiterId ON jobs(recruiterId);
      CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
      CREATE INDEX IF NOT EXISTS idx_apps_jobId ON applications(jobId);
      CREATE INDEX IF NOT EXISTS idx_apps_candidateId ON applications(candidateId);
    `);
  }

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
  }

  private mapUser(row: UserRow): User {
    return {
      id: row.id,
      email: row.email,
      password: row.password,
      fullName: row.fullName,
      role: row.role,
      company: row.company || undefined,
      title: row.title || undefined,
      createdAt: row.createdAt,
    };
  }

  private mapJob(row: JobRow): Job {
    return {
      id: row.id,
      title: row.title,
      description: row.description,
      requirements: JSON.parse(row.requirements) as string[],
      location: row.location,
      salary: JSON.parse(row.salary) as Job['salary'],
      type: row.type,
      recruiterId: row.recruiterId,
      company: row.company,
      status: row.status,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };
  }

  private mapApplication(row: ApplicationRow): Application {
    return {
      id: row.id,
      jobId: row.jobId,
      candidateId: row.candidateId,
      coverLetter: row.coverLetter,
      resume: row.resume,
      resumeFileName: row.resumeFileName || undefined,
      resumeMimeType: row.resumeMimeType || undefined,
      status: row.status,
      appliedAt: row.appliedAt,
      updatedAt: row.updatedAt,
    };
  }

  createUser(user: Omit<User, 'id' | 'createdAt'>): User {
    const id = this.generateId('user');
    const createdAt = new Date().toISOString();

    this.sqlite
      .prepare(
        `INSERT INTO users (id, email, password, fullName, role, company, title, createdAt)
         VALUES (@id, @email, @password, @fullName, @role, @company, @title, @createdAt)`
      )
      .run({
        id,
        email: user.email.toLowerCase(),
        password: user.password,
        fullName: user.fullName,
        role: user.role,
        company: user.company ?? null,
        title: user.title ?? null,
        createdAt,
      });

    return {
      ...user,
      id,
      email: user.email.toLowerCase(),
      createdAt,
    };
  }

  findUserById(id: string): User | undefined {
    const row = this.sqlite.prepare('SELECT * FROM users WHERE id = ?').get(id) as UserRow | undefined;
    return row ? this.mapUser(row) : undefined;
  }

  findUserByEmail(email: string): User | undefined {
    const row = this.sqlite
      .prepare('SELECT * FROM users WHERE email = ?')
      .get(email.toLowerCase()) as UserRow | undefined;
    return row ? this.mapUser(row) : undefined;
  }

  createJob(job: Omit<Job, 'id' | 'createdAt' | 'updatedAt'>): Job {
    const id = this.generateId('job');
    const now = new Date().toISOString();

    this.sqlite
      .prepare(
        `INSERT INTO jobs (
          id, title, description, requirements, location, salary,
          type, recruiterId, company, status, createdAt, updatedAt
        ) VALUES (
          @id, @title, @description, @requirements, @location, @salary,
          @type, @recruiterId, @company, @status, @createdAt, @updatedAt
        )`
      )
      .run({
        id,
        title: job.title,
        description: job.description,
        requirements: JSON.stringify(job.requirements ?? []),
        location: job.location,
        salary: JSON.stringify(job.salary),
        type: job.type,
        recruiterId: job.recruiterId,
        company: job.company,
        status: job.status,
        createdAt: now,
        updatedAt: now,
      });

    return {
      ...job,
      id,
      createdAt: now,
      updatedAt: now,
    };
  }

  findJobById(id: string): Job | undefined {
    const row = this.sqlite.prepare('SELECT * FROM jobs WHERE id = ?').get(id) as JobRow | undefined;
    return row ? this.mapJob(row) : undefined;
  }

  findJobsByRecruiter(recruiterId: string): Job[] {
    const rows = this.sqlite
      .prepare('SELECT * FROM jobs WHERE recruiterId = ? ORDER BY createdAt DESC')
      .all(recruiterId) as JobRow[];
    return rows.map((row) => this.mapJob(row));
  }

  findAllActiveJobs(): Job[] {
    const rows = this.sqlite
      .prepare("SELECT * FROM jobs WHERE status = 'active' ORDER BY createdAt DESC")
      .all() as JobRow[];
    return rows.map((row) => this.mapJob(row));
  }

  updateJob(id: string, updates: Partial<Job>): Job | undefined {
    const existing = this.findJobById(id);
    if (!existing) {
      return undefined;
    }

    const next: Job = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    this.sqlite
      .prepare(
        `UPDATE jobs
         SET title = @title,
             description = @description,
             requirements = @requirements,
             location = @location,
             salary = @salary,
             type = @type,
             company = @company,
             status = @status,
             updatedAt = @updatedAt
         WHERE id = @id`
      )
      .run({
        id: next.id,
        title: next.title,
        description: next.description,
        requirements: JSON.stringify(next.requirements),
        location: next.location,
        salary: JSON.stringify(next.salary),
        type: next.type,
        company: next.company,
        status: next.status,
        updatedAt: next.updatedAt,
      });

    return next;
  }

  deleteJob(id: string): boolean {
    const result = this.sqlite.prepare('DELETE FROM jobs WHERE id = ?').run(id);
    return result.changes > 0;
  }

  createApplication(application: Omit<Application, 'id' | 'appliedAt' | 'updatedAt'>): Application {
    const id = this.generateId('app');
    const now = new Date().toISOString();

    this.sqlite
      .prepare(
        `INSERT INTO applications (
          id, jobId, candidateId, coverLetter, resume,
          resumeFileName, resumeMimeType, status, appliedAt, updatedAt
        ) VALUES (
          @id, @jobId, @candidateId, @coverLetter, @resume,
          @resumeFileName, @resumeMimeType, @status, @appliedAt, @updatedAt
        )`
      )
      .run({
        id,
        jobId: application.jobId,
        candidateId: application.candidateId,
        coverLetter: application.coverLetter,
        resume: application.resume,
        resumeFileName: application.resumeFileName ?? null,
        resumeMimeType: application.resumeMimeType ?? null,
        status: application.status,
        appliedAt: now,
        updatedAt: now,
      });

    return {
      ...application,
      id,
      appliedAt: now,
      updatedAt: now,
    };
  }

  findApplicationById(id: string): Application | undefined {
    const row = this.sqlite
      .prepare('SELECT * FROM applications WHERE id = ?')
      .get(id) as ApplicationRow | undefined;
    return row ? this.mapApplication(row) : undefined;
  }

  findApplicationsByCandidate(candidateId: string): Application[] {
    const rows = this.sqlite
      .prepare('SELECT * FROM applications WHERE candidateId = ? ORDER BY appliedAt DESC')
      .all(candidateId) as ApplicationRow[];
    return rows.map((row) => this.mapApplication(row));
  }

  findApplicationsByJob(jobId: string): Application[] {
    const rows = this.sqlite
      .prepare('SELECT * FROM applications WHERE jobId = ? ORDER BY appliedAt DESC')
      .all(jobId) as ApplicationRow[];
    return rows.map((row) => this.mapApplication(row));
  }

  hasCandidateApplied(jobId: string, candidateId: string): boolean {
    const row = this.sqlite
      .prepare('SELECT 1 FROM applications WHERE jobId = ? AND candidateId = ? LIMIT 1')
      .get(jobId, candidateId) as { 1: number } | undefined;
    return !!row;
  }

  updateApplicationStatus(id: string, status: Application['status']): Application | undefined {
    const updatedAt = new Date().toISOString();
    const result = this.sqlite
      .prepare('UPDATE applications SET status = ?, updatedAt = ? WHERE id = ?')
      .run(status, updatedAt, id);

    if (result.changes === 0) {
      return undefined;
    }

    return this.findApplicationById(id);
  }

  private seedData() {
    const row = this.sqlite.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
    if (row.count > 0) {
      return;
    }

    const recruiter = this.createUser({
      email: 'recruiter@techcorp.com',
      password: '$2b$10$adeNOgG.rxzsqgAeetk0i.00fbmxtzD5YK2zRB0Uydhez63JOQK9m',
      fullName: 'Sarah Johnson',
      role: 'recruiter',
      company: 'TechCorp Inc.',
      title: 'Senior Talent Acquisition Specialist',
    });

    this.createUser({
      email: 'candidate@email.com',
      password: '$2b$10$adeNOgG.rxzsqgAeetk0i.00fbmxtzD5YK2zRB0Uydhez63JOQK9m',
      fullName: 'Michael Chen',
      role: 'candidate',
      title: 'Full Stack Developer',
    });

    const jobs: Array<Omit<Job, 'id' | 'createdAt' | 'updatedAt'>> = [
      {
        title: 'Senior Frontend Engineer',
        description:
          'We are looking for an experienced Frontend Engineer to join our growing team. You will be responsible for building scalable web applications using React, TypeScript, and modern tooling.',
        requirements: [
          '5+ years React experience',
          'TypeScript proficiency',
          'Experience with state management (Redux/Zustand)',
          'CSS/Tailwind expertise',
        ],
        location: 'San Francisco, CA (Remote)',
        salary: { min: 140000, max: 180000, currency: 'USD' },
        type: 'full-time',
        recruiterId: recruiter.id,
        company: 'TechCorp Inc.',
        status: 'active',
      },
      {
        title: 'Backend Developer - Node.js',
        description:
          'Join our backend team to build high-performance APIs and microservices. Experience with Node.js, Express, and database design required.',
        requirements: [
          '3+ years Node.js experience',
          'PostgreSQL/MongoDB knowledge',
          'RESTful API design',
          'Docker/Kubernetes experience',
        ],
        location: 'New York, NY (Hybrid)',
        salary: { min: 120000, max: 160000, currency: 'USD' },
        type: 'full-time',
        recruiterId: recruiter.id,
        company: 'TechCorp Inc.',
        status: 'active',
      },
      {
        title: 'Product Designer',
        description:
          'Seeking a creative Product Designer to craft beautiful user experiences. You will work closely with product and engineering teams.',
        requirements: [
          'Portfolio demonstrating UI/UX skills',
          'Figma expertise',
          'User research experience',
          'Design system knowledge',
        ],
        location: 'Remote',
        salary: { min: 100000, max: 140000, currency: 'USD' },
        type: 'full-time',
        recruiterId: recruiter.id,
        company: 'TechCorp Inc.',
        status: 'active',
      },
      {
        title: 'DevOps Engineer',
        description:
          'Help us build and maintain our cloud infrastructure. Experience with AWS, Terraform, and CI/CD pipelines required.',
        requirements: [
          'AWS/GCP certification preferred',
          'Terraform/CloudFormation',
          'CI/CD pipeline setup',
          'Monitoring and observability',
        ],
        location: 'Austin, TX (On-site)',
        salary: { min: 130000, max: 170000, currency: 'USD' },
        type: 'full-time',
        recruiterId: recruiter.id,
        company: 'TechCorp Inc.',
        status: 'active',
      },
    ];

    jobs.forEach((job) => this.createJob(job));
  }
}

export const db = new Database();
