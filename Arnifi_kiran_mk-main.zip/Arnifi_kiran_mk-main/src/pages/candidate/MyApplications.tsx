import { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@/hooks/redux';
import { fetchApplications, clearSuccessMessage } from '@/store/slices/applicationsSlice';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  FileText, 
  Building2, 
  MapPin, 
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  Eye
} from 'lucide-react';
import { formatDistanceToNow, formatDate } from '@/utils/date';
import type { ApplicationWithDetails, ApplicationStatus } from '@/types';

const STATUS_OPTIONS: { value: ApplicationStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All Status' },
  { value: 'pending', label: 'Pending' },
  { value: 'reviewing', label: 'Reviewing' },
  { value: 'accepted', label: 'Accepted' },
  { value: 'rejected', label: 'Rejected' },
];

export const CandidateMyApplications: React.FC = () => {
  const dispatch = useAppDispatch();
  const { applications, isLoading, error, successMessage } = useAppSelector((state) => state.applications);
  const [statusFilter, setStatusFilter] = useState<ApplicationStatus | 'all'>('all');
  const [selectedApplication, setSelectedApplication] = useState<ApplicationWithDetails | null>(null);

  useEffect(() => {
    dispatch(fetchApplications());
  }, [dispatch]);

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => {
        dispatch(clearSuccessMessage());
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [successMessage, dispatch]);

  const filteredApplications = statusFilter === 'all' 
    ? applications 
    : applications.filter(app => app.status === statusFilter);

  const getStatusConfig = (status: ApplicationStatus) => {
    switch (status) {
      case 'accepted':
        return { 
          variant: 'default' as const, 
          icon: CheckCircle2,
          color: 'text-green-500',
          message: 'Congratulations! Your application has been accepted.'
        };
      case 'rejected':
        return { 
          variant: 'destructive' as const, 
          icon: AlertCircle,
          color: 'text-red-500',
          message: 'Unfortunately, your application was not selected.'
        };
      case 'reviewing':
        return { 
          variant: 'secondary' as const, 
          icon: Eye,
          color: 'text-blue-500',
          message: 'Your application is being reviewed.'
        };
      default:
        return { 
          variant: 'outline' as const, 
          icon: Clock,
          color: 'text-yellow-500',
          message: 'Your application is pending review.'
        };
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">My Applications</h1>
          <p className="text-muted-foreground mt-1">
            Track your job applications
          </p>
        </div>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as ApplicationStatus | 'all')}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map(status => (
              <SelectItem key={status.value} value={status.value}>
                {status.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Alerts */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {successMessage && (
        <Alert>
          <CheckCircle2 className="h-4 w-4" />
          <AlertDescription>{successMessage}</AlertDescription>
        </Alert>
      )}

      {/* Applications List */}
      {filteredApplications.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">
              {statusFilter === 'all' ? 'No applications yet' : `No ${statusFilter} applications`}
            </h3>
            <p className="text-muted-foreground mb-4">
              {statusFilter === 'all' 
                ? 'Start applying to jobs to see them here' 
                : 'Try a different filter'}
            </p>
            {statusFilter === 'all' && (
              <Button asChild>
                <a href="/candidate/jobs">Browse Jobs</a>
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredApplications.map((application) => {
            const statusConfig = getStatusConfig(application.status);
            const StatusIcon = statusConfig.icon;

            return (
              <Card key={application.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-2">
                        <h3 className="font-semibold text-lg">
                          {application.job?.title}
                        </h3>
                        <Badge variant={statusConfig.variant}>
                          <StatusIcon className={`w-3 h-3 mr-1 ${statusConfig.color}`} />
                          {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                        <Building2 className="w-4 h-4" />
                        {application.job?.company}
                      </div>

                      <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {application.job?.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          Applied {formatDistanceToNow(application.appliedAt)}
                        </span>
                      </div>

                      <p className="text-sm mt-3 text-muted-foreground">
                        {statusConfig.message}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setSelectedApplication(application)}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Application Detail Dialog */}
      <Dialog open={!!selectedApplication} onOpenChange={() => setSelectedApplication(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Application Details</DialogTitle>
            <DialogDescription>
              View your application for {selectedApplication?.job?.title}
            </DialogDescription>
          </DialogHeader>

          {selectedApplication && (
            <div className="space-y-6">
              {/* Job Info */}
              <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{selectedApplication.job?.title}</h3>
                  <p className="text-sm text-muted-foreground">{selectedApplication.job?.company}</p>
                  <p className="text-sm text-muted-foreground">{selectedApplication.job?.location}</p>
                </div>
              </div>

              {/* Status */}
              <div>
                <h4 className="font-medium mb-2">Application Status</h4>
                <div className="flex items-center gap-2">
                  {(() => {
                    const config = getStatusConfig(selectedApplication.status);
                    const Icon = config.icon;
                    return (
                      <>
                        <Icon className={`w-5 h-5 ${config.color}`} />
                        <Badge variant={config.variant}>
                          {selectedApplication.status.charAt(0).toUpperCase() + selectedApplication.status.slice(1)}
                        </Badge>
                      </>
                    );
                  })()}
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  {getStatusConfig(selectedApplication.status).message}
                </p>
              </div>

              {/* Application Date */}
              <div>
                <h4 className="font-medium mb-2">Application Date</h4>
                <p className="text-sm text-muted-foreground">
                  {formatDate(selectedApplication.appliedAt)}
                </p>
              </div>

              {/* Cover Letter */}
              <div>
                <h4 className="font-medium mb-2">Your Cover Letter</h4>
                <div className="p-4 bg-muted rounded-lg text-sm whitespace-pre-wrap">
                  {selectedApplication.coverLetter}
                </div>
              </div>

              {/* Resume */}
              <div>
                <h4 className="font-medium mb-2">Your Resume</h4>
                <div className="p-4 bg-muted rounded-lg text-sm whitespace-pre-wrap">
                  {selectedApplication.resume}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CandidateMyApplications;
