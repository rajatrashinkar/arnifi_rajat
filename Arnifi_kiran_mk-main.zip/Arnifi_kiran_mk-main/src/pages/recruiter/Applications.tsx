import { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@/hooks/redux';
import { fetchApplications, updateApplicationStatus, clearSuccessMessage } from '@/store/slices/applicationsSlice';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  Users, 
  Mail, 
  Briefcase, 
  Calendar,
  AlertCircle,
  FileText,
  CheckCircle2,
  XCircle,
  Eye
} from 'lucide-react';
import { formatDistanceToNow } from '@/utils/date';
import type { ApplicationWithDetails, ApplicationStatus } from '@/types';

const STATUS_OPTIONS: { value: ApplicationStatus; label: string; color: string }[] = [
  { value: 'pending', label: 'Pending', color: 'bg-yellow-500' },
  { value: 'reviewing', label: 'Reviewing', color: 'bg-blue-500' },
  { value: 'accepted', label: 'Accepted', color: 'bg-green-500' },
  { value: 'rejected', label: 'Rejected', color: 'bg-red-500' },
];

export const RecruiterApplications: React.FC = () => {
  const dispatch = useAppDispatch();
  const { applications, isLoading, error, successMessage } = useAppSelector((state) => state.applications);
  const [selectedApplication, setSelectedApplication] = useState<ApplicationWithDetails | null>(null);
  const [statusFilter, setStatusFilter] = useState<ApplicationStatus | 'all'>('all');

  useEffect(() => {
    dispatch(fetchApplications());
  }, [dispatch]);

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => {
        dispatch(clearSuccessMessage());
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [successMessage, dispatch]);

  const handleStatusChange = async (applicationId: string, newStatus: ApplicationStatus) => {
    await dispatch(updateApplicationStatus({ applicationId, status: newStatus }));
  };

  const filteredApplications = statusFilter === 'all' 
    ? applications 
    : applications.filter(app => app.status === statusFilter);

  const getStatusBadge = (status: ApplicationStatus) => {
    const config = STATUS_OPTIONS.find(s => s.value === status);
    return (
      <Badge 
        variant={
          status === 'accepted' ? 'default' :
          status === 'rejected' ? 'destructive' :
          status === 'reviewing' ? 'secondary' :
          'outline'
        }
      >
        {config?.label || status}
      </Badge>
    );
  };

  const getResumeFileUrl = (resumePath?: string) => {
    if (!resumePath) return null;
    if (resumePath.startsWith('http://') || resumePath.startsWith('https://')) {
      return resumePath;
    }
    if (!resumePath.startsWith('/uploads/')) {
      return null;
    }

    const apiBase = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';
    const apiOrigin = apiBase.replace(/\/api\/?$/, '');
    return `${apiOrigin}${resumePath}`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Applications</h1>
          <p className="text-muted-foreground mt-1">
            Review and manage candidate applications
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as ApplicationStatus | 'all')}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              {STATUS_OPTIONS.map(status => (
                <SelectItem key={status.value} value={status.value}>
                  {status.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Alerts */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {successMessage && (
        <Alert>
          <AlertDescription>{successMessage}</AlertDescription>
        </Alert>
      )}

      {/* Applications List */}
      {filteredApplications.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No applications found</h3>
            <p className="text-muted-foreground">
              {statusFilter === 'all' 
                ? 'You haven\'t received any applications yet.' 
                : `No ${statusFilter} applications.`}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredApplications.map((application) => (
            <Card key={application.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-2">
                      <h3 className="text-lg font-semibold">
                        {application.candidate?.fullName}
                      </h3>
                      {getStatusBadge(application.status)}
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-3">
                      Applied for: <span className="font-medium text-foreground">{application.job?.title}</span>
                    </p>

                    <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
                      <span className="flex items-center gap-1">
                        <Mail className="w-4 h-4" />
                        {application.candidate?.email}
                      </span>
                      {application.candidate?.title && (
                        <span className="flex items-center gap-1">
                          <Briefcase className="w-4 h-4" />
                          {application.candidate.title}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {formatDistanceToNow(application.appliedAt)}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setSelectedApplication(application)}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    <Select 
                      value={application.status} 
                      onValueChange={(value) => handleStatusChange(application.id, value as ApplicationStatus)}
                    >
                      <SelectTrigger className="w-[130px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STATUS_OPTIONS.map(status => (
                          <SelectItem key={status.value} value={status.value}>
                            {status.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Application Detail Dialog */}
      <Dialog open={!!selectedApplication} onOpenChange={() => setSelectedApplication(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Application Details</DialogTitle>
            <DialogDescription>
              Review the candidate's application
            </DialogDescription>
          </DialogHeader>

          {selectedApplication && (
            <div className="space-y-6">
              {/* Candidate Info */}
              <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{selectedApplication.candidate?.fullName}</h3>
                  <p className="text-sm text-muted-foreground">{selectedApplication.candidate?.email}</p>
                  {selectedApplication.candidate?.title && (
                    <p className="text-sm text-muted-foreground">{selectedApplication.candidate?.title}</p>
                  )}
                </div>
              </div>

              {/* Job Info */}
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  Applied For
                </h4>
                <p className="text-sm">{selectedApplication.job?.title}</p>
                <p className="text-sm text-muted-foreground">{selectedApplication.job?.company}</p>
              </div>

              {/* Cover Letter */}
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Cover Letter
                </h4>
                <div className="p-4 bg-muted rounded-lg text-sm whitespace-pre-wrap">
                  {selectedApplication.coverLetter}
                </div>
              </div>

              {/* Resume */}
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Resume
                </h4>
                {getResumeFileUrl(selectedApplication.resume) ? (
                  <a
                    href={getResumeFileUrl(selectedApplication.resume)!}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-muted"
                  >
                    <FileText className="w-4 h-4" />
                    {selectedApplication.resumeFileName || 'Open uploaded resume'}
                  </a>
                ) : (
                  <div className="p-4 bg-muted rounded-lg text-sm whitespace-pre-wrap">
                    {selectedApplication.resume}
                  </div>
                )}
              </div>

              {/* Status & Actions */}
              <div className="flex items-center justify-between pt-4 border-t">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Current Status</p>
                  {getStatusBadge(selectedApplication.status)}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleStatusChange(selectedApplication.id, 'rejected')}
                    className="text-destructive"
                  >
                    <XCircle className="w-4 h-4 mr-1" />
                    Reject
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleStatusChange(selectedApplication.id, 'accepted')}
                  >
                    <CheckCircle2 className="w-4 h-4 mr-1" />
                    Accept
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RecruiterApplications;
