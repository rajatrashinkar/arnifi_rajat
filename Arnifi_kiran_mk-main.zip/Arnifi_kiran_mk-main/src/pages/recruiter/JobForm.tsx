import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '@/hooks/redux';
import { createJob, updateJob, fetchJob, clearError, clearSuccessMessage } from '@/store/slices/jobsSlice';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Spinner } from '@/components/ui/spinner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Plus, X, AlertCircle } from 'lucide-react';
import type { JobFormData, JobType } from '@/types';

const JOB_TYPES: JobType[] = ['full-time', 'part-time', 'contract', 'internship'];

export const JobForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const isEditing = !!id;
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { currentJob, isLoading, error, successMessage } = useAppSelector((state) => state.jobs);
  const { user } = useAppSelector((state) => state.auth);

  const [formData, setFormData] = useState<JobFormData>({
    title: '',
    description: '',
    requirements: [''],
    location: '',
    salary: {
      min: 0,
      max: 0,
      currency: 'USD',
    },
    type: 'full-time',
    company: user?.company || '',
  });

  useEffect(() => {
    if (isEditing && id) {
      dispatch(fetchJob(id));
    }
    dispatch(clearError());
    dispatch(clearSuccessMessage());
  }, [dispatch, isEditing, id]);

  useEffect(() => {
    if (isEditing && currentJob) {
      setFormData({
        title: currentJob.title,
        description: currentJob.description,
        requirements: currentJob.requirements.length > 0 ? currentJob.requirements : [''],
        location: currentJob.location,
        salary: currentJob.salary,
        type: currentJob.type,
        company: currentJob.company,
      });
    }
  }, [currentJob, isEditing]);

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => {
        navigate('/recruiter/jobs');
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [successMessage, navigate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (error) dispatch(clearError());
  };

  const handleSalaryChange = (field: 'min' | 'max', value: string) => {
    const numValue = parseInt(value) || 0;
    setFormData(prev => ({
      ...prev,
      salary: { ...prev.salary, [field]: numValue },
    }));
  };

  const handleTypeChange = (value: JobType) => {
    setFormData(prev => ({ ...prev, type: value }));
  };

  const handleRequirementChange = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      requirements: prev.requirements.map((req, i) => i === index ? value : req),
    }));
  };

  const addRequirement = () => {
    setFormData(prev => ({
      ...prev,
      requirements: [...prev.requirements, ''],
    }));
  };

  const removeRequirement = (index: number) => {
    setFormData(prev => ({
      ...prev,
      requirements: prev.requirements.filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Filter out empty requirements
    const cleanedData = {
      ...formData,
      requirements: formData.requirements.filter(req => req.trim() !== ''),
    };

    if (isEditing && id) {
      await dispatch(updateJob({ id, data: cleanedData }));
    } else {
      await dispatch(createJob(cleanedData));
    }
  };

  const isSubmitting = isLoading;

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => navigate('/recruiter/jobs')}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">
            {isEditing ? 'Edit Job' : 'Post New Job'}
          </h1>
          <p className="text-muted-foreground text-sm">
            {isEditing ? 'Update your job posting' : 'Create a new job opening'}
          </p>
        </div>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {successMessage && (
        <Alert className="mb-4">
          <AlertDescription>{successMessage}</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Job Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Job Title */}
            <div className="space-y-2">
              <Label htmlFor="title">Job Title *</Label>
              <Input
                id="title"
                name="title"
                placeholder="e.g., Senior Frontend Engineer"
                value={formData.title}
                onChange={handleChange}
                required
              />
            </div>

            {/* Company */}
            <div className="space-y-2">
              <Label htmlFor="company">Company Name</Label>
              <Input
                id="company"
                name="company"
                placeholder="e.g., Acme Inc."
                value={formData.company}
                onChange={handleChange}
              />
            </div>

            {/* Location & Type */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="location">Location *</Label>
                <Input
                  id="location"
                  name="location"
                  placeholder="e.g., San Francisco, CA (Remote)"
                  value={formData.location}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Job Type *</Label>
                <Select value={formData.type} onValueChange={handleTypeChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select job type" />
                  </SelectTrigger>
                  <SelectContent>
                    {JOB_TYPES.map(type => (
                      <SelectItem key={type} value={type}>
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Salary Range */}
            <div className="space-y-2">
              <Label>Salary Range (USD)</Label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Input
                    type="number"
                    placeholder="Minimum"
                    value={formData.salary.min || ''}
                    onChange={(e) => handleSalaryChange('min', e.target.value)}
                  />
                </div>
                <div>
                  <Input
                    type="number"
                    placeholder="Maximum"
                    value={formData.salary.max || ''}
                    onChange={(e) => handleSalaryChange('max', e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Job Description *</Label>
              <Textarea
                id="description"
                name="description"
                placeholder="Describe the role, responsibilities, and what you're looking for..."
                value={formData.description}
                onChange={handleChange}
                rows={6}
                required
              />
            </div>

            {/* Requirements */}
            <div className="space-y-2">
              <Label>Requirements</Label>
              <div className="space-y-2">
                {formData.requirements.map((req, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      placeholder={`Requirement ${index + 1}`}
                      value={req}
                      onChange={(e) => handleRequirementChange(index, e.target.value)}
                    />
                    {formData.requirements.length > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => removeRequirement(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addRequirement}
                className="mt-2"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Requirement
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex justify-end gap-4 mt-6">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate('/recruiter/jobs')}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <Spinner className="w-4 h-4 mr-2" />
                {isEditing ? 'Updating...' : 'Posting...'}
              </>
            ) : (
              isEditing ? 'Update Job' : 'Post Job'
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default JobForm;
