# Frontend README

## Overview

This frontend is a React + TypeScript single-page app for JobConnect Pro.

Main responsibilities:
- Auth screens and session handling
- Role-based routing and protected pages
- Recruiter and candidate dashboards
- Job listing and application workflows
- Resume/CV upload in apply dialog

## Folder Map

```text
src/
├── App.tsx                 # Router and top-level providers
├── main.tsx                # App entry point
├── api/                    # Axios instance + endpoint wrappers
├── components/             # Shared components and UI primitives
├── hooks/                  # Custom hooks
├── layouts/                # Auth and dashboard layouts
├── pages/
│   ├── auth/               # Login/Signup pages
│   ├── candidate/          # Candidate pages
│   └── recruiter/          # Recruiter pages
├── store/
│   ├── index.ts            # Redux store
│   └── slices/             # auth/jobs/applications slices
├── types/                  # Shared interfaces and types
└── utils/                  # Utility helpers
```

## Run Frontend

From project root:

```bash
npm run dev
```

Default URL:
- http://localhost:5173

## State Management

Redux Toolkit slices:
- authSlice: login/signup/session/role state
- jobsSlice: recruiter and candidate job operations
- applicationsSlice: apply flow and recruiter review flow

## API Integration

Axios client file:
- src/api/axios.ts

Default API base URL:
- http://localhost:3001/api

You can override with:
- VITE_API_URL in environment config

## Resume/CV Upload Flow

Candidate apply dialog sends multipart/form-data with:
- coverLetter
- resumeFile

The API returns an application object containing:
- resume: uploaded file path
- resumeFileName: original file name
- resumeMimeType: uploaded file mime type

Recruiter application details page renders a link for uploaded resume files.

## UX and Routing

- React Router 7 with role-based route protection
- Custom route error boundary for better 404/error UX
- Loading and error feedback in async screens

## Notes for Evaluator

- This app is intentionally designed as a full-stack internship assignment demo.
- Frontend relies on backend seed data and auth flow.
- Best way to run full app: npm run dev:full from root.
