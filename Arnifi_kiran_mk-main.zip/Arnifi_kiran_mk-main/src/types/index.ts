/**
 * TypeScript Type Definitions for JobConnect Pro
 */

// User Types
export type UserRole = 'recruiter' | 'candidate';

export interface User {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
  company?: string;
  title?: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

// Job Types
export type JobType = 'full-time' | 'part-time' | 'contract' | 'internship';
export type JobStatus = 'active' | 'closed' | 'draft';

export interface Salary {
  min: number;
  max: number;
  currency: string;
}

export interface Job {
  id: string;
  title: string;
  description: string;
  requirements: string[];
  location: string;
  salary: Salary;
  type: JobType;
  recruiterId: string;
  company: string;
  status: JobStatus;
  createdAt: string;
  updatedAt: string;
}

export interface JobsState {
  jobs: Job[];
  currentJob: Job | null;
  isLoading: boolean;
  error: string | null;
  successMessage: string | null;
}

// Application Types
export type ApplicationStatus = 'pending' | 'reviewing' | 'accepted' | 'rejected';

export interface Application {
  id: string;
  jobId: string;
  candidateId: string;
  coverLetter: string;
  resume: string;
  resumeFileName?: string;
  resumeMimeType?: string;
  status: ApplicationStatus;
  appliedAt: string;
  updatedAt: string;
}

export interface ApplicationWithDetails extends Application {
  job?: {
    id: string;
    title: string;
    company: string;
    location?: string;
    type?: JobType;
  } | null;
  candidate?: {
    id: string;
    fullName: string;
    email: string;
    title?: string;
  } | null;
}

export interface ApplicationsState {
  applications: ApplicationWithDetails[];
  isLoading: boolean;
  error: string | null;
  successMessage: string | null;
}

// API Response Types
export interface ApiResponse<T = unknown> {
  success: boolean;
  message?: string;
  data?: T;
}

export interface AuthResponse {
  user: User;
  token: string;
}

// Form Types
export interface LoginFormData {
  email: string;
  password: string;
}

export interface SignupFormData {
  email: string;
  password: string;
  fullName: string;
  role: UserRole;
  company?: string;
  title?: string;
}

export interface JobFormData {
  title: string;
  description: string;
  requirements: string[];
  location: string;
  salary: {
    min: number;
    max: number;
    currency: string;
  };
  type: JobType;
  company?: string;
}

export interface ApplicationFormData {
  coverLetter: string;
  resume?: string;
  resumeFile?: File | null;
}

// UI Types
export interface Toast {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
}

export interface UIState {
  toasts: Toast[];
  sidebarOpen: boolean;
}
