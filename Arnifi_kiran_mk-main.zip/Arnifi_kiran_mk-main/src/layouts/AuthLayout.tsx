import { Link } from 'react-router-dom';
import { Briefcase } from 'lucide-react';

export const AuthLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3">
            <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-lg">
              <Briefcase className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="font-bold text-2xl">JobConnect Pro</span>
          </Link>
          <p className="mt-2 text-muted-foreground">
            Connect with top talent and opportunities
          </p>
        </div>

        {/* Content */}
        <div className="bg-card rounded-2xl shadow-xl border border-border p-6 lg:p-8">
          {children}
        </div>

        {/* Footer */}
        <p className="text-center mt-8 text-sm text-muted-foreground">
          © {new Date().getFullYear()} JobConnect Pro. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default AuthLayout;
