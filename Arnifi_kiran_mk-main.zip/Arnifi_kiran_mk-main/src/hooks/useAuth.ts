import { useEffect } from 'react';
import { useAppSelector, useAppDispatch } from './redux';
import { restoreSession } from '@/store/slices/authSlice';

export const useAuth = () => {
  const dispatch = useAppDispatch();
  const { user, token, isAuthenticated, isLoading, error } = useAppSelector((state) => state.auth);

  useEffect(() => {
    // Try to restore session if token exists but user is not authenticated
    if (token && !isAuthenticated && !isLoading) {
      dispatch(restoreSession());
    }
  }, [dispatch, token, isAuthenticated, isLoading]);

  return {
    user,
    token,
    isAuthenticated,
    isLoading,
    error,
    isRecruiter: user?.role === 'recruiter',
    isCandidate: user?.role === 'candidate',
  };
};

export default useAuth;
