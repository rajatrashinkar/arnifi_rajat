// App.tsx - Main Application Router
import { 
  createBrowserRouter, 
  RouterProvider, 
  Navigate,
  Outlet,
  Link,
  isRouteErrorResponse,
  useRouteError,
} from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from '@/store';
import { useAuth } from '@/hooks/useAuth';

// Layouts
import { AuthLayout } from '@/layouts/AuthLayout';
import { DashboardLayout } from '@/layouts/DashboardLayout';

// Pages
import { Landing } from '@/pages/Landing';
import { Login } from '@/pages/auth/Login';
import { Signup } from '@/pages/auth/Signup';
import { RecruiterDashboard } from '@/pages/recruiter/Dashboard';
import { RecruiterJobsList } from '@/pages/recruiter/JobsList';
import { JobForm } from '@/pages/recruiter/JobForm';
import { RecruiterApplications } from '@/pages/recruiter/Applications';
import { CandidateJobDiscovery } from '@/pages/candidate/JobDiscovery';
import { CandidateMyApplications } from '@/pages/candidate/MyApplications';
import { CandidateProfile } from '@/pages/candidate/Profile';

// Protected Route Components
import { RecruiterRoute, CandidateRoute } from '@/components/ProtectedRoute';

// Role-based redirect component
const RoleBasedRedirect: React.FC = () => {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (user?.role === 'recruiter') {
    return <Navigate to="/recruiter/dashboard" replace />;
  }

  return <Navigate to="/candidate/jobs" replace />;
};

// Dashboard wrapper with layout
const DashboardWrapper: React.FC = () => (
  <DashboardLayout>
    <Outlet />
  </DashboardLayout>
);

// Global route error boundary for data/router errors and 404s
const RouteErrorBoundary: React.FC = () => {
  const error = useRouteError();

  const title = isRouteErrorResponse(error)
    ? error.status === 404
      ? 'Page Not Found'
      : `Error ${error.status}`
    : 'Something Went Wrong';

  const message = isRouteErrorResponse(error)
    ? error.statusText || 'The requested page could not be loaded.'
    : 'An unexpected error occurred while loading this page.';

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-6">
      <div className="max-w-lg text-center space-y-4">
        <p className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
          Oops
        </p>
        <h1 className="text-3xl font-bold">{title}</h1>
        <p className="text-muted-foreground">{message}</p>
        <div className="pt-2">
          <Link
            to="/"
            className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            Go back home
          </Link>
        </div>
      </div>
    </div>
  );
};

// Define routes
const router = createBrowserRouter([
  {
    path: '/',
    element: <Outlet />,
    errorElement: <RouteErrorBoundary />,
    children: [
      // Public routes
      {
        index: true,
        element: <Landing />,
      },
      {
        path: 'login',
        element: (
          <AuthLayout>
            <Login />
          </AuthLayout>
        ),
      },
      {
        path: 'signup',
        element: (
          <AuthLayout>
            <Signup />
          </AuthLayout>
        ),
      },

      // Role-based redirect for /dashboard
      {
        path: 'dashboard',
        element: <RoleBasedRedirect />,
      },

      // Recruiter routes
      {
        path: 'recruiter',
        element: (
          <RecruiterRoute>
            <DashboardWrapper />
          </RecruiterRoute>
        ),
        children: [
          {
            path: 'dashboard',
            element: <RecruiterDashboard />,
          },
          {
            path: 'jobs',
            element: <RecruiterJobsList />,
          },
          {
            path: 'jobs/new',
            element: <JobForm />,
          },
          {
            path: 'jobs/edit/:id',
            element: <JobForm />,
          },
          {
            path: 'applications',
            element: <RecruiterApplications />,
          },
        ],
      },

      // Candidate routes
      {
        path: 'candidate',
        element: (
          <CandidateRoute>
            <DashboardWrapper />
          </CandidateRoute>
        ),
        children: [
          {
            path: 'jobs',
            element: <CandidateJobDiscovery />,
          },
          {
            path: 'applications',
            element: <CandidateMyApplications />,
          },
          {
            path: 'profile',
            element: <CandidateProfile />,
          },
        ],
      },

      // Catch all - redirect to landing
      {
        path: '*',
        element: <Navigate to="/" replace />,
      },
    ],
  },
]);

// App component with Redux Provider
function App() {
  return (
    <Provider store={store}>
      <RouterProvider router={router} />
    </Provider>
  );
}

export default App;
