import { Navigate, useLocation, Outlet } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import type { UserRole } from '@/types';
import { Spinner } from '@/components/ui/spinner';

interface ProtectedRouteProps {
  allowedRoles?: UserRole[];
  children?: React.ReactNode;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  allowedRoles, 
  children
}) => {
  const { isAuthenticated, isLoading, user } = useAuth();
  const location = useLocation();

  // Show loading spinner while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Spinner className="h-8 w-8" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Not authenticated - redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Check role-based access
  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    // User doesn't have required role - redirect to appropriate dashboard
    if (user.role === 'recruiter') {
      return <Navigate to="/recruiter/dashboard" replace />;
    } else {
      return <Navigate to="/candidate/jobs" replace />;
    }
  }

  // Render children or outlet
  return <>{children || <Outlet />}</>;
};

// Pre-configured route guards
export const RecruiterRoute: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <ProtectedRoute allowedRoles={['recruiter']}>
    {children || <Outlet />}
  </ProtectedRoute>
);

export const CandidateRoute: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <ProtectedRoute allowedRoles={['candidate']}>
    {children || <Outlet />}
  </ProtectedRoute>
);

export const AuthenticatedRoute: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <ProtectedRoute>
    {children || <Outlet />}
  </ProtectedRoute>
);

export default ProtectedRoute;
