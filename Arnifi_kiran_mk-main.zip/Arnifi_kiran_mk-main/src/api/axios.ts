import axios, { AxiosError, type AxiosInstance, type AxiosResponse, type InternalAxiosRequestConfig } from 'axios';
import { store } from '@/store';
import { logout } from '@/store/slices/authSlice';

// API base URL
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Create axios instance
const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// Request interceptor - add auth token
apiClient.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem('token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error: AxiosError) => {
    return Promise.reject(error);
  }
);

// Response interceptor - handle errors
apiClient.interceptors.response.use(
  (response: AxiosResponse) => response,
  (error: AxiosError) => {
    if (error.response) {
      const { status } = error.response;

      // Handle 401 Unauthorized - token expired or invalid
      if (status === 401) {
        const errorData = error.response.data as { message?: string };
        
        // Only logout if it's a token-related error
        if (errorData?.message?.includes('token') || errorData?.message?.includes('expired')) {
          store.dispatch(logout());
          window.location.href = '/login?session=expired';
        }
      }

      // Handle 403 Forbidden
      if (status === 403) {
        console.error('Access forbidden:', error.response.data);
      }
    }

    return Promise.reject(error);
  }
);

export default apiClient;
