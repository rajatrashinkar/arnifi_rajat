import apiClient from './axios';
import type { 
  ApiResponse, 
  Application, 
  ApplicationWithDetails, 
  ApplicationFormData,
  ApplicationStatus 
} from '@/types';

export const applicationsApi = {
  /**
   * Get all applications
   * - Candidates: returns their own applications
   * - Recruiters: returns applications for their jobs
   */
  getApplications: async (): Promise<ApplicationWithDetails[]> => {
    const response = await apiClient.get<ApiResponse<{ applications: ApplicationWithDetails[] }>>('/applications');
    return response.data.data!.applications;
  },

  /**
   * Apply for a job (candidate only)
   */
  applyForJob: async (jobId: string, data: ApplicationFormData): Promise<ApplicationWithDetails> => {
    const payload = new FormData();
    payload.append('coverLetter', data.coverLetter);

    if (data.resumeFile) {
      payload.append('resumeFile', data.resumeFile);
    }

    if (data.resume) {
      payload.append('resume', data.resume);
    }

    const response = await apiClient.post<ApiResponse<{ application: ApplicationWithDetails }>>(
      `/applications/jobs/${jobId}/apply`,
      payload,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );
    return response.data.data!.application;
  },

  /**
   * Update application status (recruiter only)
   */
  updateApplicationStatus: async (
    applicationId: string, 
    status: ApplicationStatus
  ): Promise<Application> => {
    const response = await apiClient.put<ApiResponse<{ application: Application }>>(
      `/applications/${applicationId}/status`,
      { status }
    );
    return response.data.data!.application;
  },

  /**
   * Get applications for a specific job (recruiter only)
   */
  getJobApplications: async (jobId: string): Promise<{ applications: ApplicationWithDetails[]; job: { id: string; title: string } }> => {
    const response = await apiClient.get<ApiResponse<{ applications: ApplicationWithDetails[]; job: { id: string; title: string } }>>(
      `/applications/job/${jobId}`
    );
    return response.data.data!;
  },
};
