import apiClient from './axios';
import type { ApiResponse, Job, JobFormData } from '@/types';

export const jobsApi = {
  /**
   * Get all jobs
   * - Recruiters: returns their own jobs
   * - Candidates/Public: returns all active jobs
   */
  getJobs: async (): Promise<Job[]> => {
    const response = await apiClient.get<ApiResponse<{ jobs: Job[] }>>('/jobs');
    return response.data.data!.jobs;
  },

  /**
   * Get single job by ID
   */
  getJob: async (id: string): Promise<Job> => {
    const response = await apiClient.get<ApiResponse<{ job: Job }>>(`/jobs/${id}`);
    return response.data.data!.job;
  },

  /**
   * Create new job (recruiter only)
   */
  createJob: async (data: JobFormData): Promise<Job> => {
    const response = await apiClient.post<ApiResponse<{ job: Job }>>('/jobs', data);
    return response.data.data!.job;
  },

  /**
   * Update existing job (recruiter only, own jobs)
   */
  updateJob: async (id: string, data: Partial<JobFormData>): Promise<Job> => {
    const response = await apiClient.put<ApiResponse<{ job: Job }>>(`/jobs/${id}`, data);
    return response.data.data!.job;
  },

  /**
   * Delete job (recruiter only, own jobs)
   */
  deleteJob: async (id: string): Promise<void> => {
    await apiClient.delete<ApiResponse<void>>(`/jobs/${id}`);
  },
};
