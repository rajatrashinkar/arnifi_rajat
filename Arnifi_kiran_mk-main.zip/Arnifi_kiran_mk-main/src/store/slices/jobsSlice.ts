import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
import { jobsApi } from '@/api/jobsApi';
import type { JobsState, Job, JobFormData } from '@/types';

// Initial state
const initialState: JobsState = {
  jobs: [],
  currentJob: null,
  isLoading: false,
  error: null,
  successMessage: null,
};

// Async thunks
export const fetchJobs = createAsyncThunk(
  'jobs/fetchJobs',
  async (_, { rejectWithValue }) => {
    try {
      const jobs = await jobsApi.getJobs();
      return jobs;
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to fetch jobs.';
      return rejectWithValue(message);
    }
  }
);

export const fetchJob = createAsyncThunk(
  'jobs/fetchJob',
  async (id: string, { rejectWithValue }) => {
    try {
      const job = await jobsApi.getJob(id);
      return job;
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to fetch job details.';
      return rejectWithValue(message);
    }
  }
);

export const createJob = createAsyncThunk(
  'jobs/createJob',
  async (data: JobFormData, { rejectWithValue }) => {
    try {
      const job = await jobsApi.createJob(data);
      return job;
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to create job.';
      return rejectWithValue(message);
    }
  }
);

export const updateJob = createAsyncThunk(
  'jobs/updateJob',
  async ({ id, data }: { id: string; data: Partial<JobFormData> }, { rejectWithValue }) => {
    try {
      const job = await jobsApi.updateJob(id, data);
      return job;
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to update job.';
      return rejectWithValue(message);
    }
  }
);

export const deleteJob = createAsyncThunk(
  'jobs/deleteJob',
  async (id: string, { rejectWithValue }) => {
    try {
      await jobsApi.deleteJob(id);
      return id;
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to delete job.';
      return rejectWithValue(message);
    }
  }
);

// Jobs slice
const jobsSlice = createSlice({
  name: 'jobs',
  initialState,
  reducers: {
    setCurrentJob: (state, action: PayloadAction<Job | null>) => {
      state.currentJob = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
    clearSuccessMessage: (state) => {
      state.successMessage = null;
    },
    clearJobs: (state) => {
      state.jobs = [];
      state.currentJob = null;
    },
  },
  extraReducers: (builder) => {
    // Fetch Jobs
    builder
      .addCase(fetchJobs.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchJobs.fulfilled, (state, action) => {
        state.isLoading = false;
        state.jobs = action.payload;
      })
      .addCase(fetchJobs.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });

    // Fetch Single Job
    builder
      .addCase(fetchJob.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchJob.fulfilled, (state, action) => {
        state.isLoading = false;
        state.currentJob = action.payload;
      })
      .addCase(fetchJob.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });

    // Create Job
    builder
      .addCase(createJob.pending, (state) => {
        state.isLoading = true;
        state.error = null;
        state.successMessage = null;
      })
      .addCase(createJob.fulfilled, (state, action) => {
        state.isLoading = false;
        state.jobs.unshift(action.payload);
        state.successMessage = 'Job posted successfully!';
      })
      .addCase(createJob.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });

    // Update Job
    builder
      .addCase(updateJob.pending, (state) => {
        state.isLoading = true;
        state.error = null;
        state.successMessage = null;
      })
      .addCase(updateJob.fulfilled, (state, action) => {
        state.isLoading = false;
        const index = state.jobs.findIndex(job => job.id === action.payload.id);
        if (index !== -1) {
          state.jobs[index] = action.payload;
        }
        if (state.currentJob?.id === action.payload.id) {
          state.currentJob = action.payload;
        }
        state.successMessage = 'Job updated successfully!';
      })
      .addCase(updateJob.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });

    // Delete Job
    builder
      .addCase(deleteJob.pending, (state) => {
        state.isLoading = true;
        state.error = null;
        state.successMessage = null;
      })
      .addCase(deleteJob.fulfilled, (state, action) => {
        state.isLoading = false;
        state.jobs = state.jobs.filter(job => job.id !== action.payload);
        if (state.currentJob?.id === action.payload) {
          state.currentJob = null;
        }
        state.successMessage = 'Job deleted successfully!';
      })
      .addCase(deleteJob.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  },
});

export const { setCurrentJob, clearError, clearSuccessMessage, clearJobs } = jobsSlice.actions;
export default jobsSlice.reducer;
