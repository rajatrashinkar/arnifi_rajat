import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { applicationsApi } from '@/api/applicationsApi';
import type { ApplicationsState, ApplicationFormData, ApplicationStatus } from '@/types';

// Initial state
const initialState: ApplicationsState = {
  applications: [],
  isLoading: false,
  error: null,
  successMessage: null,
};

// Async thunks
export const fetchApplications = createAsyncThunk(
  'applications/fetchApplications',
  async (_, { rejectWithValue }) => {
    try {
      const applications = await applicationsApi.getApplications();
      return applications;
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to fetch applications.';
      return rejectWithValue(message);
    }
  }
);

export const applyForJob = createAsyncThunk(
  'applications/applyForJob',
  async ({ jobId, data }: { jobId: string; data: ApplicationFormData }, { rejectWithValue }) => {
    try {
      const application = await applicationsApi.applyForJob(jobId, data);
      return application;
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to submit application.';
      return rejectWithValue(message);
    }
  }
);

export const updateApplicationStatus = createAsyncThunk(
  'applications/updateApplicationStatus',
  async ({ applicationId, status }: { applicationId: string; status: ApplicationStatus }, { rejectWithValue }) => {
    try {
      const application = await applicationsApi.updateApplicationStatus(applicationId, status);
      return application;
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to update application status.';
      return rejectWithValue(message);
    }
  }
);

// Applications slice
const applicationsSlice = createSlice({
  name: 'applications',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    clearSuccessMessage: (state) => {
      state.successMessage = null;
    },
    clearApplications: (state) => {
      state.applications = [];
    },
  },
  extraReducers: (builder) => {
    // Fetch Applications
    builder
      .addCase(fetchApplications.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchApplications.fulfilled, (state, action) => {
        state.isLoading = false;
        state.applications = action.payload;
      })
      .addCase(fetchApplications.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });

    // Apply for Job
    builder
      .addCase(applyForJob.pending, (state) => {
        state.isLoading = true;
        state.error = null;
        state.successMessage = null;
      })
      .addCase(applyForJob.fulfilled, (state, action) => {
        state.isLoading = false;
        state.applications.unshift(action.payload);
        state.successMessage = 'Application submitted successfully!';
      })
      .addCase(applyForJob.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });

    // Update Application Status
    builder
      .addCase(updateApplicationStatus.pending, (state) => {
        state.isLoading = true;
        state.error = null;
        state.successMessage = null;
      })
      .addCase(updateApplicationStatus.fulfilled, (state, action) => {
        state.isLoading = false;
        const index = state.applications.findIndex(app => app.id === action.payload.id);
        if (index !== -1) {
          state.applications[index] = { ...state.applications[index], ...action.payload };
        }
        state.successMessage = `Application ${action.payload.status} successfully!`;
      })
      .addCase(updateApplicationStatus.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearError, clearSuccessMessage, clearApplications } = applicationsSlice.actions;
export default applicationsSlice.reducer;
